/* tslint:disable */
require("./AnalyticsSettingsButton.module.css");
const styles = {
  container: 'container_579adb75',
  iconButton: 'iconButton_579adb75',
};

export default styles;
/* tslint:enable */