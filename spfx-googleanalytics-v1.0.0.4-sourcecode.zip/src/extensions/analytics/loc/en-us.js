define([], function() {
  return {
    "Title": "AnalyticsApplicationCustomizer"
  }
});