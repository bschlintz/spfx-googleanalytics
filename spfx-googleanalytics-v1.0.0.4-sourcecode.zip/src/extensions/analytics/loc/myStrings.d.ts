declare interface IAnalyticsApplicationCustomizerStrings {
  Title: string;
}

declare module 'AnalyticsApplicationCustomizerStrings' {
  const strings: IAnalyticsApplicationCustomizerStrings;
  export = strings;
}
